valorUno = float(input("Ingrese el primer valor: "))
valorDos = float(input("Ingrese el segundo valor: "))
suma = valorUno + valorDos
resta = valorUno - valorDos
multiplicacion = valorUno * valorDos
division = valorUno / valorDos
print(f"La suma de {valorUno} y {valorDos} es: {suma}")
print(f"La resta de {valorUno} y {valorDos} es: {resta}")
print(f"La multiplicacion de {valorUno} y {valorDos} es: {multiplicacion}")
print(f"La division de {valorUno} y {valorDos} es: {division}")
